module.exports.admin = require("./admin.model");
module.exports.user = require("./user.model");
module.exports.restaurant = require("./restaurant.model");
module.exports.states = require("./states.model");
module.exports.owner = require("./owners.model");
module.exports.order = require("./order.model");
module.exports.city = require("./city.model");
module.exports.dashboard = require("./dashboard.model");