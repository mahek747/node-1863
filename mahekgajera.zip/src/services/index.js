module.exports.userService = require("./user.service");
module.exports.adminService = require("./admin.service");
module.exports.cityService = require("./city.service");
module.exports.statesService = require("./states.service");
module.exports.restaurantService = require("./restaurant.service");
module.exports.dashboardService = require("./dashboard.service");
module.exports.ownerService = require("./owners.service");
module.exports.orderService = require("./order.service");