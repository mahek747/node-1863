module.exports.userValidation = require("./user.validation");
module.exports.adminValidation = require("./admin.validation");
module.exports.restaurantValidation = require("./restaurant.validation");
module.exports.dashboardValidation = require("./dashboard.validation");
module.exports.ownersValidation = require("./owners.validation");
module.exports.orderValidation = require("./order.validation");
module.exports.cityValidation = require("./city.validation");
module.exports.statesValidation = require("./states.validation");