module.exports.userController = require("./user.controller");
module.exports.adminController = require("./admin.controller");
module.exports.dashboardController = require("./dashboard.controller");
module.exports.orderController = require("./order.contoller");
module.exports.ownersController = require("./owners.controller");
module.exports.restaurantController = require("./restaurant.controller");
module.exports.statesController = require("./states.controller");
module.exports.cityController = require("./city.controller");